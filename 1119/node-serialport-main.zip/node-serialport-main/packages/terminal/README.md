# @serialport/terminal

See the documentation at https://serialport.io/docs/bin-terminal
