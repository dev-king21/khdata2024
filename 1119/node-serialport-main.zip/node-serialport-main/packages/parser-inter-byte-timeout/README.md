# @serialport/parser-inter-byte-timeout

See our api docs https://serialport.io/docs/api-parser-inter-byte-timeout
