# @serialport/parser-packet-length

The documentation at https://serialport.io/docs/api-parser-packet-length
