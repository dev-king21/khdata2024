# @serialport/repl

See the documentation at https://serialport.io/docs/bin-repl
