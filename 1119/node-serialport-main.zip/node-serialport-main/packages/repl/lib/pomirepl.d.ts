declare module 'promirepl'
