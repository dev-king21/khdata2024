# @serialport/parser-slip-encoder

See our api docs https://serialport.io/docs/api-parser-slip-encoder
