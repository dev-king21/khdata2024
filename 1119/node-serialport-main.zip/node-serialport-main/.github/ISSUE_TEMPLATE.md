## 👉 [Please follow one of these issue templates](https://github.com/serialport/node-serialport/issues/new/choose) 👈
