# Security Policy

## Supported Versions

We currently support the latest version of serialport only.

| Version | Supported          |
| ------- | ------------------ |
| 9.x.x   | :white_check_mark: |
| < 9.0.x | :x:                |

## Reporting a Vulnerability

Please email security@serialport.io if you find any issues and we'll talk about it. You can find a GPG key on keybase.
