module.exports = {
  bail: true,
  require: ['esbuild-register'],
  spec: ['packages/**/*.test.ts'],
}
