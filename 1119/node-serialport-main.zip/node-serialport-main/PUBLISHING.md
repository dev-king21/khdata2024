# How to publish node Serialport

Two factor auth is required for publishing.

1. run `npm run build`
1. run `npm run publish`
1. Let everyone know 🎉
