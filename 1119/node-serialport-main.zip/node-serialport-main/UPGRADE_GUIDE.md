# Upgrade Guide

Moved to https://serialport.io/docs/guide-upgrade
